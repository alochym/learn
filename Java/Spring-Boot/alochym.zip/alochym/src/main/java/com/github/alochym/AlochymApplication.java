package com.github.alochym;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlochymApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlochymApplication.class, args);
	}

}
