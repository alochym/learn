package com.github.alochym;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlochymApplicationTests {

	@Test
	void contextLoads() {
	}

}
